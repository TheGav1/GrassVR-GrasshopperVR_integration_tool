# K2Goals
Example Goals for use with the Kangaroo2 solver
